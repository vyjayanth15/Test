package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.fms.bean.Course;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.util.DBConnection;
import com.cg.fms.util.SQLQueries;

public class CourseDaoImpl implements ICourseDao{
	public static final	Logger LOGGER = Logger.getLogger(CourseDaoImpl.class);
	@Override
	public String addCourse(Course courseDto) throws FeedbackException {

		LOGGER.info("Inserting course details into database");
		String courseId=null;
		int queryResult = 0;
		try (Connection connection = DBConnection.getInstance();
				PreparedStatement preparedStatement = connection
						.prepareStatement(SQLQueries.INSERT_COURSE_QUERY);
				PreparedStatement preparedStatement1 = connection.prepareStatement(SQLQueries.QUERY_SEQUENCE);

				){
			preparedStatement.setString(1, courseDto.getCourseName());
			preparedStatement.setString(2, courseDto.getNoOfDays());

			queryResult = preparedStatement.executeUpdate();
			ResultSet resultSet = preparedStatement1.executeQuery();

			if (resultSet.next()) {
				courseId = resultSet.getString(1);

			}
			if (queryResult == 0) {
				throw new FeedbackException("Error in entering course details");

			} 
		} catch (SQLException exception) {
			LOGGER.error("SQL Exception occured!");
			throw new FeedbackException("SQL Exception occured!"+exception.getMessage());
		} 

		return courseId;
	}

	@Override
	public List<Course> displayCourseDetails() throws FeedbackException {
		// TODO Auto-generated method stub

		List<Course> list=new ArrayList<Course>();
		try(Connection connection = DBConnection.getInstance();
				PreparedStatement 	preparedStatement = connection
						.prepareStatement(SQLQueries.DISPLAY_COURSE_LIST_QUERY);
				) {

			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				Course courseDto=new Course();
				courseDto.setCourseId(resultSet.getInt(1)+"");
				courseDto.setCourseName(resultSet.getString(2)); 
				courseDto.setNoOfDays(resultSet.getString(3));
				list.add(courseDto);
			}
		} catch (SQLException exception) {
			LOGGER.info("Error in retriving data" +exception.getMessage());
			throw new FeedbackException(exception.getMessage());
		} 

		return list;
	}

	@Override
	public Course viewCourseDetails(String courseId) throws FeedbackException {
		

		Course courseDto = null;
		try(	Connection con = DBConnection.getInstance();
				PreparedStatement preparedStatement 
				= con.prepareStatement(SQLQueries.VIEW_COURSE_DETAILS_QUERY);
				) {

			preparedStatement.setString(1, courseId);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				courseDto = new Course();
				courseDto.setCourseName(resultSet.getString(1));
				courseDto.setNoOfDays(resultSet.getString(2));
			}
		} catch (SQLException exception) {
			throw new FeedbackException(exception.getMessage());
		} 

		return courseDto;
	}

	@Override
	public boolean updateCourserDetails(String cId, Course courseDto)
			throws FeedbackException {

		try(	Connection connection = DBConnection.getInstance();
				PreparedStatement	preparedStatement=
						connection.prepareStatement(SQLQueries.UPDATE_QUERY);

				) {

			preparedStatement.setString(1,courseDto.getCourseName());
			preparedStatement.setInt(2,Integer.parseInt(courseDto.getNoOfDays()));
			preparedStatement.setInt(3,Integer.parseInt(cId));
			int result=preparedStatement.executeUpdate();
			if(result==1){
				return true;
			}
			else {
				return false;
			}

		} catch (SQLException exception) {
			LOGGER.error("Error in fetching course details" + exception.getMessage());
			throw new FeedbackException(exception.getMessage());
		}
	}
	@Override
	public boolean deleteCourseDetails(String cID) throws FeedbackException {



		try(Connection connection = DBConnection.getInstance();
				PreparedStatement pst
				=connection.prepareStatement(SQLQueries.DELETE_COURSE_QUERY);
				) {

			pst.setString(1, cID);
			int result=pst.executeUpdate();
			if(result==1){
				return true;
			}
			else{
				return false;
			}
		} catch (SQLException exception) {
			LOGGER.error("Error in fetching course details" + exception.getMessage());

			throw new FeedbackException(exception.getMessage());
		}

	}

}
