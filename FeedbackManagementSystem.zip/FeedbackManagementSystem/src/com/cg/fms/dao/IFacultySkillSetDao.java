package com.cg.fms.dao;

import java.util.List;

import com.cg.fms.bean.FacultySkill;
import com.cg.fms.exception.FeedbackException;

public interface IFacultySkillSetDao {

	List<FacultySkill> showFacultySkillSet() throws FeedbackException;
}
