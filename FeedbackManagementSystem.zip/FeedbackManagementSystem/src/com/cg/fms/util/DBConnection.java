package com.cg.fms.util;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

	
	public static Connection getInstance() {
	    Connection connection = null;
	    
			
			if(connection==null) 
				
			try {
				Class.forName("com.mysql.jdbc.Driver");  
				connection=DriverManager.getConnection(  
				"jdbc:mysql://localhost:3306/feedback","root","India123");  
			} 
		 catch (SQLException e) {
			System.err.println("SQL Exception occured" + e.getMessage());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return connection;
}
}