package org.cap.bean;

import java.time.LocalDate;

public class TransactionBean {

	private Integer transactionId;
	private String empId;
	private Integer calculatedkm;
	private Double monthlyFee;
	private LocalDate startDate;
	private String status;
	
	public TransactionBean() {
		
	}
	
	public TransactionBean(Integer transactionId, String empId, Integer calculatedkm, Double monthlyFee,
			LocalDate startDate, String status) {
		super();
		this.transactionId = transactionId;
		this.empId = empId;
		this.calculatedkm = calculatedkm;
		this.monthlyFee = monthlyFee;
		this.startDate = startDate;
		this.status = status;
	}

	public Integer getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public Integer getCalculatedkm() {
		return calculatedkm;
	}

	public void setCalculatedkm(Integer calculatedkm) {
		this.calculatedkm = calculatedkm;
	}

	public Double getMonthlyFee() {
		return monthlyFee;
	}

	public void setMonthlyFee(Double monthlyFee) {
		this.monthlyFee = monthlyFee;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "TransactionBean [transactionId=" + transactionId + ", empId=" + empId + ", calculatedkm=" + calculatedkm
				+ ", monthlyFee=" + monthlyFee + ", startDate=" + startDate + ", status=" + status + "]";
	}
	
	
}
