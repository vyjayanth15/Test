package org.cap.bean;

public class RouteBean {

	private Integer routeId;
	private String routeName;
	private String routePath;
	private Integer occupiedSeats;
	private Integer totalSeats;
	private String busNo;
	private String driverNo;
	private Integer totalkm;
	
	public RouteBean() {
		
	}
	
	public RouteBean(Integer routeId, String routeName, String routePath, Integer occupiedSeats, Integer totalSeats,
			String busNo, String driverNo, Integer totalkm) {
		super();
		this.routeId = routeId;
		this.routeName = routeName;
		this.routePath = routePath;
		this.occupiedSeats = occupiedSeats;
		this.totalSeats = totalSeats;
		this.busNo = busNo;
		this.driverNo = driverNo;
		this.totalkm = totalkm;
	}

	
	public String getRoutePath() {
		return routePath;
	}

	public void setRoutePath(String routePath) {
		this.routePath = routePath;
	}

	public Integer getRouteId() {
		return routeId;
	}
	public void setRouteId(Integer routeId) {
		this.routeId = routeId;
	}
	public String getRouteName() {
		return routeName;
	}
	public void setRouteName(String route) {
		this.routeName = route;
	}
	public Integer getOccupiedSeats() {
		return occupiedSeats;
	}
	public void setOccupiedSeats(Integer occupiedSeats) {
		this.occupiedSeats = occupiedSeats;
	}
	public Integer getTotalSeats() {
		return totalSeats;
	}
	public void setTotalSeats(Integer totalSeats) {
		this.totalSeats = totalSeats;
	}
	public String getBusNo() {
		return busNo;
	}
	public void setBusNo(String busNo) {
		this.busNo = busNo;
	}
	public String getDriverNo() {
		return driverNo;
	}
	public void setDriverNo(String driverNo) {
		this.driverNo = driverNo;
	}
	public Integer getTotalkm() {
		return totalkm;
	}
	public void setTotalkm(Integer totalkm) {
		this.totalkm = totalkm;
	}
	
	@Override
	public String toString() {
		return "RouteBean [routeId=" + routeId + ", route=" + routeName + ", occupiedSeats=" + occupiedSeats
				+ ", totalSeats=" + totalSeats + ", busNo=" + busNo + ", driverNo=" + driverNo + ", totalkm=" + totalkm
				+ "]";
	}
	
	
}
