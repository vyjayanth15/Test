package org.cap.service;

import java.util.List;

import org.cap.bean.BusBean;
import org.cap.bean.RouteBean;

public class BusServiceImpl implements IBusService {

	@Override
	public BusBean createRequest(BusBean busBean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BusBean> pendingRequest() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RouteBean> getAllRoutes() {
		// TODO Auto-generated method stub
		return null;
	}

}
