package org.cap.service;

import java.util.List;

import org.cap.bean.BusBean;
import org.cap.bean.RouteBean;

public interface IBusService {
	public BusBean createRequest(BusBean busBean);
	public List<BusBean> pendingRequest();
	public List<RouteBean> getAllRoutes();
}
