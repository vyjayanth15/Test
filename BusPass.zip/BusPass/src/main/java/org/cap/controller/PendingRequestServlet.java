package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.bean.BusBean;
import org.cap.service.BusServiceImpl;
import org.cap.service.IBusService;


@WebServlet("/PendingRequestServlet")
public class PendingRequestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private IBusService busService;
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		busService=new BusServiceImpl();
		PrintWriter out=response.getWriter();
		List<BusBean> bus=busService.pendingRequest();
		out.println("<html>"
				+ "<body>");
		out.println("<h3>All Route Details</h3>"
				+ "<table>"
				+ "<tr>"
				+ "<th>ReqhestId</th>"
				+ "<th>EmployeeId</th>"
				+ "<th>Location</th>"
				+ "<th>PickUpLocation</th>"
				+ "<th>Status</th>"
				+ "<th></th>"
				+ "</tr>");
		for(BusBean busBean:bus) {
			out.println("<tr>"
					+ "<td>"+busBean.getRequestId()+"</td>"
					+ "<td>"+busBean.getEmployee_id()+"<br>"
					+"<td>"+busBean.getPickupLocation()+"</td>"
					+ "<td>"+busBean.getStatus()+"</td>"
					+ "<td><input type='hidden' value='"+ "<button value='Approve' onclick='Request'>  </td>"
					+ "</tr>");
		}
		
	out.println("</table>");
		
		
		out.println("</body>"
				+ "</html>");
	}
}
