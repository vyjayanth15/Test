package org.cap.dao;

import java.util.List;

import org.cap.bean.BusBean;

public interface IBusDao {
	public List<BusBean> pendingRequest();
	public BusBean createRequest(BusBean busBean);

}
