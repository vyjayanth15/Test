package org.cap.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

import org.cap.bean.BusBean;

public class BusDaoImpl implements IBusDao {

	@Override
	public List<BusBean> pendingRequest() {
		List<BusBean> busbean=new ArrayList<>();
		String sql="select * from busspassrequest where status='Pending'";
		try(
				Statement st=DBConnection.getConnection().createStatement();
				){
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				BusBean bean=new BusBean();
				bean.setRequestId(rs.getInt(1));
				bean.setEmployee_id(rs.getString(2));
				bean.setFirstName(rs.getString(3));
				bean.setLastName(rs.getString(4));
				bean.setAddress(rs.getString(5));
				bean.setEmailId(rs.getString(6));
				bean.setGender(rs.getString(7));
				bean.setLocation(rs.getString(8));
				bean.setDofjoining(rs.getDate(9).toLocalDate());
				bean.setPickupLocation(rs.getString(10));
				bean.setPickupTime(rs.getTime(11).toLocalTime());
				bean.setDesignation(rs.getString(12));
				busbean.add(bean);
			}
			return busbean;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public BusBean createRequest(BusBean busBean) {
		String sql="insert into buspassrequest(employeeid,firstname,lastname,gender,address,email,dateofjoining,location,"
				+ "pickuplocation,pickuptime,status,designation) values(?,?,?,?,?,?,?,?,?,?,?,?)";
		try(PreparedStatement pst = DBConnection.getConnection().prepareStatement(sql);){
			pst.setString(1, busBean.getEmployee_id());
			pst.setString(2, busBean.getFirstName());
			pst.setString(3, busBean.getLastName());
			pst.setString(4, busBean.getGender());
			pst.setString(5, busBean.getAddress());
			pst.setString(6, busBean.getEmailId());
			pst.setDate(7, Date.valueOf(busBean.getDofjoining()));
			pst.setString(8, busBean.getLocation());
			pst.setString(9, busBean.getPickupLocation());
			pst.setTime(10, Time.valueOf(busBean.getPickupTime()));
			pst.setString(11, busBean.getStatus());
			pst.setString(12, busBean.getDesignation());
			
			
			int count=pst.executeUpdate();
			if(count>0) {
				return busBean;
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
}
