package org.cap.dao;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.cap.bean.LoginBean;



public class LoginDaoImpl implements ILoginDao{

	@Override
	public boolean isValidLogin(LoginBean loginBean) {
		String sql="select * from adminlogin where username=? and password=?";
		try(PreparedStatement ps=DBConnection.getConnection().prepareStatement(sql)){
			ps.setString(1,loginBean.getUserName());
			ps.setString(2,loginBean.getPassword());
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	

}
