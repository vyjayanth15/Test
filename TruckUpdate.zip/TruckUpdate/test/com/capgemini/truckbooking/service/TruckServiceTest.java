package com.capgemini.truckbooking.service;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TruckServiceTest {
	
	ITruckService service=new TruckService();
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("Initializing Test Case");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("Cleanup after Test Case");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("Initializing Test Method");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("Cleanup after Test Method");
}

	@Test
	public void testIsvalidCustomerId() {
		assertTrue(service.isvalidCustomerId("A111111"));
	}
	
	@Test
	public void testIsNotvalidCustomerId() {
		assertFalse(service.isvalidCustomerId("A11111"));
	}
}
