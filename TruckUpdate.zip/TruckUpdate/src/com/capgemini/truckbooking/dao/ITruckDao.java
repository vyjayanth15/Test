package com.capgemini.truckbooking.dao;

import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.TruckBookingException;

public interface ITruckDao {

	List<TruckBean> retrieveTruckDetails()throws TruckBookingException;
	Integer bookTrucks(BookingBean bookingBean)throws TruckBookingException;
	Integer getBookingId()throws TruckBookingException;
}
