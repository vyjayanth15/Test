package com.capgemini.truckbooking.service;

import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.TruckBookingException;

public interface ITruckService {
	
	List<TruckBean> retrieveTruckDetails()throws TruckBookingException;
	Integer bookTrucks(BookingBean bookingBean)throws TruckBookingException;
	boolean isvalidCustomerId(String customerId);
	boolean truckAvailable(int numberofTrucks, int truckId)throws TruckBookingException;

}
