package com.capgemini.truckbooking.service;

import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.dao.ITruckDao;
import com.capgemini.truckbooking.dao.TruckDao;
import com.capgemini.truckbooking.exception.TruckBookingException;

public class TruckService implements ITruckService {

	ITruckDao dao=new TruckDao();

	@Override
	public List<TruckBean> retrieveTruckDetails() throws TruckBookingException {
		return dao.retrieveTruckDetails() ;
	}

	@Override
	public Integer bookTrucks(BookingBean bookingBean)
			throws TruckBookingException {
		return dao.bookTrucks(bookingBean);
	}

	@Override
	public boolean isvalidCustomerId(String customerId) {
		String regex="^[A-Z]{1}[0-9]{6}$";
		return customerId.matches(regex);
	}

	@Override
	public boolean truckAvailable(int numberofTrucks, int truckId) throws TruckBookingException {
		boolean flag=false;
		if(numberofTrucks>0){
			List<TruckBean> list=dao.retrieveTruckDetails();
			for(TruckBean bean:list){
				if(bean.getTruckId()==truckId && bean.getAvailableNos()<numberofTrucks){
					flag=true;
				}
			}
		}
		return flag;
	}
}
