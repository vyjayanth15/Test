package com.capgemini.truckbooking.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.TruckBookingException;
import com.capgemini.truckbooking.utility.DBConnection;
import com.capgemini.truckbooking.utility.QueryMapper;

public class TruckDao implements ITruckDao {


	@Override
	public List<TruckBean> retrieveTruckDetails() throws TruckBookingException {
		List<TruckBean> list=new ArrayList<TruckBean>();
		try( Connection con=DBConnection.getConnection();
				Statement statement=con.createStatement();
				) {
			ResultSet resultSet=statement.executeQuery(QueryMapper.ALLTRUCKS);
			while(resultSet.next()){
				TruckBean bean=new TruckBean();
				bean.setAvailableNos(resultSet.getInt("availableNos"));
				bean.setCharges(resultSet.getFloat("charges"));
				bean.setDestination(resultSet.getString("destination"));
				bean.setOrigin(resultSet.getString("origin"));
				bean.setTruckId(resultSet.getInt("truckId"));
				bean.setTruckType(resultSet.getString("trucktype"));

				list.add(bean);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public Integer bookTrucks(BookingBean bookingBean)
			throws TruckBookingException {
		try( Connection con=DBConnection.getConnection();
				PreparedStatement preparedStatement
				=con.prepareStatement(QueryMapper.BOOKING);
				PreparedStatement preparedStatement1
				=con.prepareStatement(QueryMapper.UPDATE_TRUCKS);
				) {
			preparedStatement.setString(1, bookingBean.getCustId());
			preparedStatement.setLong(2, bookingBean.getCustMobile());
			preparedStatement.setInt(3, bookingBean.getTruckId());
			preparedStatement.setInt(4, bookingBean.getNoOfTrucks());

			Date d1= Date.valueOf(bookingBean.getDateOfTransport());
			preparedStatement.setDate(5, d1);
			preparedStatement1.setInt(1, bookingBean.getNoOfTrucks());
			preparedStatement1.setInt(2, bookingBean.getTruckId());

			int n=preparedStatement.executeUpdate();
			
			if(n>0){
				int m=preparedStatement1.executeUpdate();
				if(m>0){
					bookingBean.setBookingId(getBookingId());
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

		return bookingBean.getBookingId();
	}

	@Override
	public Integer getBookingId() throws TruckBookingException {
		int id=0;
		try( Connection con=DBConnection.getConnection();
				Statement statement=con.createStatement();
				) {
			ResultSet resultSet=statement.executeQuery(QueryMapper.GETBOOKINGID);
			if(resultSet.next()){
				id=resultSet.getInt(1);
			}
			return id;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return id;
	}

}
