package com.capgemini.truckbooking.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.TruckBookingException;
import com.capgemini.truckbooking.service.ITruckService;
import com.capgemini.truckbooking.service.TruckService;

public class BookingClient {

	public static ITruckService service=new TruckService();
	public static Logger uiLogger=Logger.getLogger(BookingClient.class);
	public static void main(String[] args) throws TruckBookingException {
		Scanner scanner=new Scanner(System.in);
		int opt;
		do{
			uiLogger.info("Inside Do-While Loop");
			System.out.println("---------Truck Booking-----------");
			System.out.println("1.Book Trucks");
			System.out.println("2.Exit");
			System.out.println("Selct an option");
			opt=scanner.nextInt();
			scanner.nextLine();
			if(opt==1){
				System.out.println("Enter CustomerId");
				String customerId=scanner.nextLine();
				if(isvalidCustomerId(customerId)){
					System.out.println("List of Trucks");
					List<TruckBean> list=service.retrieveTruckDetails();
					for(TruckBean bean:list){
						System.out.println(bean);
					}
					System.out.println("Please Enter the TruckId from the above List");
					int truckId=scanner.nextInt();
					System.out.println("Enter number of Trucks");
					int numberofTrucks=scanner.nextInt();
					if(truckAvailable(numberofTrucks,truckId)){
						System.out.println("Enter Customer Mobile Number");
						long mobileNumber=scanner.nextLong();
						scanner.nextLine();
						System.out.println("Enter the Date in this format yyyy-MM-dd");
						String str=scanner.nextLine();
						DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
						LocalDate date=LocalDate.parse(str, formatter);

						BookingBean bookingBean =new BookingBean();
						bookingBean.setCustId(customerId);
						bookingBean.setCustMobile(mobileNumber);
						bookingBean.setDateOfTransport(date);
						bookingBean.setNoOfTrucks(numberofTrucks);
						bookingBean.setTruckId(truckId);

						int bookingId=service.bookTrucks(bookingBean);
						if(bookingId>0){
							System.out.println("Thank you.Your Booking Id is:"+bookingId);
						}

					}
				}else{
					System.out.println("Invalid CustomerID");
				}
			}else if(opt==2){
				System.exit(0);
			}else{
				System.out.println("Please select a valid option");
			}
		}while(opt!=2);
		scanner.close();
		System.out.println("Exit");
	}

	private static boolean truckAvailable(int numberofTrucks, int truckId) throws TruckBookingException {
		return service.truckAvailable(numberofTrucks,truckId);
	}

	private static boolean isvalidCustomerId(String customerId) {
		return service.isvalidCustomerId(customerId);
	}

}
