package com.capgemini.truckbooking.utility;

public class QueryMapper {
	
	public static final String ALLTRUCKS="select * from truckdetails";
	public static final String BOOKING="insert into bookingdetails values(booking_id_seq.nextval,?,?,?,?,?)";
	public static final String GETBOOKINGID="select max(bookingid) from bookingdetails";
	public static final String UPDATE_TRUCKS="update truckdetails set availablenos=availablenos-? where truckid=?";
}
